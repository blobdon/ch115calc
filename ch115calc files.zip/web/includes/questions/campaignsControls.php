<div class='span8'>
  <!-- <input type="checkbox" name='campaigns[]' id='campaignsInclude' value='Optional' class='hide' checked> -->
  <label class="checkbox inline" for='Lcampaign'>
    <input type='checkbox' name='campaigns[]' id='Lcampaign' value='Lcampaign'<?php retain_Checkbox('campaigns','Lcampaign'); ?>>Lebanon Campaign
  </label>
  <label class="checkbox inline" for='Gcampaign'>
    <input type='checkbox' name='campaigns[]' id='Gcampaign' value='Gcampaign'<?php retain_Checkbox('campaigns','Gcampaign'); ?>>Grenada Campaign
  </label>
  <label class="checkbox inline" for='Pcampaign'>
    <input type='checkbox' name='campaigns[]' id='Pcampaign' value='Pcampaign'<?php retain_Checkbox('campaigns','Pcampaign'); ?>>Panama Campaign
  </label>
</div>