<?php echo $_SESSION['vetResidePrior'];?>
