<?php echo $_SESSION['applicant']==='Dependent'?"Did the Veteran":'Did you' ?> serve in armed conflict as a member of the American Merchant Marine during the following period?
