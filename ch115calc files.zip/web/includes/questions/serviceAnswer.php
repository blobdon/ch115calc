<?php echo ''.$_SESSION['branch'].'; '.$_SESSION['serviceStart'].' to '.$_SESSION['serviceEnd'].'; '.$_SESSION['discharge'].' discharge';?>
