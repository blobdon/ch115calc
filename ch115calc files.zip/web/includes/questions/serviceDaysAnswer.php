<?php echo $_SESSION['serviceDays'];?>
