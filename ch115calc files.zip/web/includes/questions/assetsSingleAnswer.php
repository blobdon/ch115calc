<?php echo $_SESSION['assetsSingle'];?>
