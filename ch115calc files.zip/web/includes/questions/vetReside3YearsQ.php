Have you <?php echo $_SESSION['applicant']==='Dependent'?'and/or the Veteran':''; ?> lived in Massachusetts <abbr title="">continuosly</abbr> for 3 or more years?
