<div class=''> 
	<strong>How do you get paid?</strong>
	<a href='#' class='label'>WEEKLY &times;</a>
	<span class='label'>2 WEEKS &times;</span>
	<span class='label'>TWICE per MONTH &times;</span>
	<span class='label'>MONTHLY &times;</span>
	<label class="radio" for='weeklyPay'>
		<input type='radio' name='pay' id='weeklyPay' value='4'>
		I get paid EVERY WEEK
	</label>
	<div id='getWeeklyPay' class='getPay'>
		<p>Enter the amount your last 4 paychecks. Do not include federal/state taxes or mandatory retirement, health, and hospital payments</p>
	</div>
	<label class="radio" for='biweeklyPay'>
		<input type='radio' name='pay' id='biweeklyPay' value='2'>
		I get paid EVERY 2 WEEKS
	</label>
	<div id='getBiweeklyPay' class='getPay'>
		<p>Enter the amount your last 2 paychecks. Do not include federal/state taxes or mandatory retirement, health, and hospital payments</p>
	</div>
	<label class="radio" for='semimonthlyPay'>
		<input type='radio' name='pay' id='semimonthlyPay' value='2'>
		I get paid TWICE PER MONTH (e.g. 1st and 15th of each month)
	</label>
	<div id='getSemimonthlyPay' class='getPay'>
		<p>Enter the amount your last 2 paychecks. Do not include federal/state taxes or mandatory retirement, health, and hospital payments</p>
	</div>
	<label class="radio" for='monthlyPay'>
		<input type='radio' name='pay' id='monthlyPay' value='1'>
		I get paid EVERY MONTH
	</label>
	<div id='getMonthlyPay' class='getPay'>
		<p>Enter the amount your last paycheck. Do not include federal/state taxes or mandatory retirement, health, and hospital payments</p>
	</div>
	<label class="radio" for='noPay'>
		<input type='radio' name='pay' id='noPay' value='0'>
		I am unemployed, I get NO pay
	</label>
</div>

	<input type="text" id='paycheck1' class='span1' placeholder='Check 1'>
	<input type="text" id='paycheck2' class='span1' placeholder='Check 2'>
	<input type="text" id='paycheck3' class='span1' placeholder='Check 3'>
	<input type="text" id='paycheck4' class='span1' placeholder='Check 4'>

<?
?>