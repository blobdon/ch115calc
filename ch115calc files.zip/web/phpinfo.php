<?php
  // ini_set('session.save_handler','files');
  // ini_set('session.save_path',dirname(__FILE__).'/sessiondata');
  // error_reporting(E_ALL);
  // ini_set('display_errors', 'off');
  // ini_set('date.timezone', 'UTC');
  phpinfo();
 ?>