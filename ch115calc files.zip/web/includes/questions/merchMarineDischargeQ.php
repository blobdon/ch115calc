<?php echo $_SESSION['applicant']==='Dependent'?"Did the Veteran":'Did you' ?> receive a discharge from the U.S. Coast Guard, Army, or Navy?
