<?php echo $_SESSION['applicant']==='Dependent'?"Was the Veteran":'Were you' ?> awarded a Korea Defense Service Medal?
