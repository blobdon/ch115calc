<?php echo $_SESSION['shelterType'];?>
