<?php echo $_SESSION['assetsMarried'];?>
