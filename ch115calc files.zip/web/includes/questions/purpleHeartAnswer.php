<?php echo $_SESSION['purpleHeart'];?>
