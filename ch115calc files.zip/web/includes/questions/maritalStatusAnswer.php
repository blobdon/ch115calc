<?php echo $_SESSION['maritalStatus'];?>
