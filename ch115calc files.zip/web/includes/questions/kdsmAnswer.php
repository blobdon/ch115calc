<?php echo $_SESSION['kdsm'];?>
