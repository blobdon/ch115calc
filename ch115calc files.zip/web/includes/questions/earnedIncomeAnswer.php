<?php echo '$ '.$_SESSION['earnedIncome'];?>
