<?php echo '$ '.$_SESSION['otherIncome'];?>
