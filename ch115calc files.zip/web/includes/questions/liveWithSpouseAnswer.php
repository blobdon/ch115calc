<?php echo $_SESSION['liveWithSpouse'];?>
