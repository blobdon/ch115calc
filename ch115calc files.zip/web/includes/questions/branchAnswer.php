<?php echo $_SESSION['branch'];?>
