<?php echo '$ '.$_SESSION['heatingCost'];?>
