<?php echo '$ '.$_SESSION['housingCost'];?>
